# fastapi 项目克隆命令行工具

> Ps: 浅用 [Typer](https://typer.tiangolo.com/)

## 使用
###### P.S.: 未上传到 PyPI

方式一：克隆到本地
```shell
# install 
git clone https://gitee.com/wu_cl/fastapi_ccli

# dep
portry install

# help
python main.py --help
# or
python main.py cloner --help

# run
python main.py
```

方式二：安装包
```text

```

## 测试
根目录下执行 `$ pytest`