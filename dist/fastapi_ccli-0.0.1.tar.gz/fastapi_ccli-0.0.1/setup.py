# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fastapi_ccli', 'fastapi_ccli.CN', 'fastapi_ccli.EN', 'fastapi_ccli.utils']

package_data = \
{'': ['*']}

install_requires = \
['questionary==1.10.0', 'requests==2.25.1', 'typer[all]==0.4.1']

entry_points = \
{'console_scripts': ['fastapi_ccli = fastapi_ccli.main:main']}

setup_kwargs = {
    'name': 'fastapi-ccli',
    'version': '0.0.1',
    'description': 'Tool to automatically clone existing fastapi repositories based on command line conditions',
    'long_description': '# fastapi 项目克隆命令行工具\n\n> Ps: 浅用 [Typer](https://typer.tiangolo.com/)\n\n## 使用\n###### P.S.: 未上传到 PyPI\n\n方式一：克隆到本地\n```shell\n# install \ngit clone https://gitee.com/wu_cl/fastapi_ccli\n\n# dep\nportry install\n\n# help\npython main.py --help\n# or\npython main.py cloner --help\n\n# run\npython main.py\n```\n\n方式二：安装包\n```text\n\n```\n\n## 测试\n根目录下执行 `$ pytest`',
    'author': 'wu',
    'author_email': 'jianhengwu0407@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/wu-clan/fastapi_ccli',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
