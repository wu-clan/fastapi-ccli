# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fastapi_ccli', 'fastapi_ccli.CN', 'fastapi_ccli.EN', 'fastapi_ccli.utils']

package_data = \
{'': ['*']}

install_requires = \
['questionary==1.10.0', 'requests==2.25.1', 'typer[all]==0.4.1']

entry_points = \
{'console_scripts': ['fastapi_ccli = fastapi_ccli.main:main']}

setup_kwargs = {
    'name': 'fastapi-ccli',
    'version': '0.0.1',
    'description': 'Tool to automatically clone existing fastapi repositories based on command line conditions',
    'long_description': '# fastapi 项目克隆命令行工具\n\n> Ps: 浅用 [Typer](https://typer.tiangolo.com/)\n\n## 使用\n\n###### P.S.: 未上传到 PyPI, 两种方式选其一, 按步骤在命令行执行即可\n\n### 1. 克隆仓库\n\nclone\n\n```shell\ngit clone https://gitee.com/wu_cl/fastapi_ccli\n```\n\ninstall dep\n\n```shell\nportry install\n```\n\nhelp\n\n```shell\n# 进入 fastapi_ccli 目录下\n\npython main.py --help\n# or\npython main.py cloner --help\n```\n\nrun\n\n```shell\n# 进入 fastapi_ccli 目录下\n\npython main.py\n```\n\n---\n\n### 2. 安装 whl 包\n\ninstall whl\n\n[点击下载](https://gitee.com/wu_cl/fastapi_ccli/raw/master/dist/fastapi_ccli-0.0.1-py3-none-any.whl)\n\n[备用1](https://github.com/wu-clan/fastapi_ccli/blob/master/dist/fastapi_ccli-0.0.1-py3-none-any.whl?raw=true)\n\n[备用2](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/wu-clan/fastapi_ccli/blob/master/dist/fastapi_ccli-0.0.1-py3-none-any.whl)\n\npip\n\n```shell\n# 在 whl 包存放目录执行:\n\npip install fastapi_ccli-0.0.1-py3-none-any.whl\n```\n\nhelp\n\n```shell\n# 进入 fastapi_ccli 目录下\n\nfastapi_ccli --help\n# or\nfastapi_ccli cloner --help\n```\n\nrun\n\n```shell\n# 进入 fastapi_ccli 目录下\n\nfastapi_ccli\n```\n\n## 测试\n\n根目录下执行 `pytest`',
    'author': 'wu',
    'author_email': 'jianhengwu0407@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/wu-clan/fastapi_ccli',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
